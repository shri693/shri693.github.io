# -*- coding: utf-8 -*-
from . import part_number_generation