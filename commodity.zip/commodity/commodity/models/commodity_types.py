# -*- coding: utf-8 -*-
from odoo import models, fields, api

class CommodityType(models.Model):
    _name = 'commodity.type'
    _description = 'Commodity Type'
    
    name = fields.Char('Name')
    description = fields.Char('Description')
    
class CommodityTypeMech(models.Model):
    _name = 'commodity.type.mech'
    
    com_type_id = fields.Many2one('commodity.type', 'Commodity Type')
    type_id = fields.Many2one('com.type', 'Type')
    material_id = fields.Many2one('com.material', 'Material')
    description = fields.Char('Description')
    
    @api.multi
    def generate_part_number(self):
        part_number = self.env['part.number'].create({
            'com_type_id' : self.com_type_id.id,
            'name' : 'MECH' + self.env['ir.sequence'].get('part.number'),
            'description' : "Type : {}\nMaterial : {}".format(self.type_id.name, self.material_id.name)
            })
        return {
            'type' : 'ir.actions.act_window',
            'res_model' : 'part.number',
            'view_type' : 'form',
            'view_mode' : 'form',
            'res_id' : part_number.id
            }
    
class PartNumber(models.Model):
    _name = 'part.number'
    _description = 'Part Number'
    
    com_type_id = fields.Many2one('commodity.type', 'Commodity Type')
    name = fields.Char('Number')
    description = fields.Char('Description')
    
class ComType(models.Model):
    _name = 'com.type'
    _description = 'Com Type'
    
    name = fields.Char('Name')
    
class Material(models.Model):
    _name = 'com.material'
    _description = 'Material'
    
    name = fields.Char('Name')
    
class Tolerance(models.Model):
    _name = 'com.tolerance'
    _description = 'Tolerance'
    
    name = fields.Char('Name')
    
class Power(models.Model):
    _name = 'com.power'
    _description = 'Power'
    
    name = fields.Char('Name')
    
class AssyType(models.Model):
    _name = 'com.assy.type'
    _description = 'Assy Type'
    
    name = fields.Char('Name')
    
class Package(models.Model):
    _name = 'com.package'
    _description = 'Package'
    
    name = fields.Char('Name')
    
class CommodityTypeReg(models.Model):
    _name = 'commodity.type.reg'
    
    com_type_id = fields.Many2one('commodity.type', 'Commodity Type')
    type_id = fields.Many2one('com.type', 'Type')
    value = fields.Char('Value')
    tolerance_id = fields.Many2one('com.tolerance', 'Tolerance')
    power_id = fields.Many2one('com.power', 'Power')
    assy_type_id = fields.Many2one('com.assy.type', 'Assy Type')
    package_id = fields.Many2one('com.package', 'Package')
    
    @api.multi
    def generate_part_number(self):
        part_number = self.env['part.number'].create({
            'com_type_id' : self.com_type_id.id,
            'name' : 'MECH' + self.env['ir.sequence'].get('part.number'),
            'description' : "Type : {}\nValue : {}\nTolerance : {}\nPower : {}\nAssy Type : {}\nPackage : {}".format(self.type_id.name, 
                                                                                                                     self.value, self.tolerance_id.name, self.power_id,
                                                                                                                     self.assy_type_id.name, self.package_id.name)
            })
        return {
            'type' : 'ir.actions.act_window',
            'res_model' : 'part.number',
            'view_type' : 'form',
            'view_mode' : 'form',
            'res_id' : part_number.id
            }
    