# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PartNumberGenerationWiz(models.TransientModel):
    _name = 'part.number.generation'
    _description = 'Part Number Generation Wiz'

    com_type_id = fields.Many2one('commodity.type', 'Commodity Type')

    @api.multi
    def action_part_generation_wiz(self):
        if self.com_type_id.name == 'MECH':
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'commodity.type.mech',
                'view_type': 'form',
                'view_mode': 'form',
                'target': 'new',
                'context': {'default_com_type_id': self.com_type_id.id}
            }

        if self.com_type_id.name == 'REG':
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'commodity.type.reg',
                'view_type': 'form',
                'view_mode': 'form',
                'target': 'new',
                'context': {'default_com_type_id': self.com_type_id.id}
            }
