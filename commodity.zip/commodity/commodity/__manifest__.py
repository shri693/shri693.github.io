# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

{
    'name': 'Comodity',
    'version': "10.0.1",
    'author': "Divergent",
    'website': 'http://www.odoo.com',
    'license': "AGPL-3",
    'summary': 'A Module For part number creation using commodities',
    'complexity': 'easy',
    'depends': [],
    'data': [
        'data.xml',
        'views/commodity_type_view.xml',
        'wizard/part_number_generation.xml',
    ],
    'installable': True,
    'application': True
}
